const OPENAI_URL = "https://api.openai.com/v1/responses";
const MAX_BODY_BYTES = 8 * 1024 * 1024;

function corsHeaders(origin, allowedOrigin) {
  const allowed = allowedOrigin && allowedOrigin !== "*" ? allowedOrigin : origin;
  return {
    "Access-Control-Allow-Origin": allowed || "null",
    "Access-Control-Allow-Methods": "POST, OPTIONS",
    "Access-Control-Allow-Headers": "Content-Type",
    "Vary": "Origin",
  };
}

function json(data, status, origin, env) {
  return new Response(JSON.stringify(data), {
    status,
    headers: { "Content-Type": "application/json; charset=utf-8", ...corsHeaders(origin, env.ALLOWED_ORIGIN) },
  });
}

function cleanMessages(messages) {
  if (!Array.isArray(messages)) return [];
  return messages.slice(-12).map((m) => ({
    role: m?.role === "assistant" ? "assistant" : "user",
    content: String(m?.content || "").slice(0, 4000),
  }));
}

async function callOpenAI(body, env) {
  const response = await fetch(OPENAI_URL, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": `Bearer ${env.OPENAI_API_KEY}`,
    },
    body: JSON.stringify(body),
  });
  const data = await response.json().catch(() => ({}));
  if (!response.ok) {
    const message = data?.error?.message || `OpenAI returned ${response.status}`;
    throw new Error(message);
  }
  return data;
}

function outputText(data) {
  if (typeof data?.output_text === "string") return data.output_text.trim();
  return (data?.output || [])
    .flatMap((item) => item?.content || [])
    .filter((part) => part?.type === "output_text")
    .map((part) => part.text || "")
    .join("\n")
    .trim();
}

export default {
  async fetch(request, env) {
    const origin = request.headers.get("Origin") || "";
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: corsHeaders(origin, env.ALLOWED_ORIGIN) });
    if (request.method !== "POST") return json({ error: "Method not allowed" }, 405, origin, env);
    if (!env.OPENAI_API_KEY) return json({ error: "OPENAI_API_KEY is not configured on the Worker" }, 500, origin, env);
    if (env.ALLOWED_ORIGIN && env.ALLOWED_ORIGIN !== "*" && origin !== env.ALLOWED_ORIGIN) return json({ error: "Origin not allowed" }, 403, origin, env);

    const contentLength = Number(request.headers.get("Content-Length") || 0);
    if (contentLength > MAX_BODY_BYTES) return json({ error: "Request too large" }, 413, origin, env);

    let body;
    try { body = await request.json(); } catch { return json({ error: "Invalid JSON" }, 400, origin, env); }

    try {
      if (body.action === "chat") {
        const messages = cleanMessages(body.messages);
        const context = body.context || {};
        const system = `تو دستیار تغذیه‌ی اپ «سفره‌ی من» هستی. به فارسی پاسخ بده، کوتاه و دقیق باش. در محاسبات کالری و درشت‌مغذی‌ها از داده‌های روز کاربر که در context آمده استفاده کن. اگر داده‌ای برای پاسخ کافی نیست، صریح بگو که نمی‌دانی و عددسازی نکن. هدف‌های روزانه کاربر: ${JSON.stringify(context.targets || {})}. غذاهای ثبت‌شده امروز: ${JSON.stringify(context.today || [])}.`;
        const data = await callOpenAI({
          model: "gpt-5-mini",
          store: false,
          input: [
            { role: "developer", content: [{ type: "input_text", text: system }] },
            ...messages.map((m) => ({ role: m.role, content: [{ type: "input_text", text: m.content }] })),
          ],
        }, env);
        return json({ text: outputText(data) }, 200, origin, env);
      }

      if (body.action === "analyze-food") {
        const image = body.image || {};
        if (!image.data) return json({ error: "Image data is required" }, 400, origin, env);
        const mime = String(image.mime || "image/jpeg");
        if (!/^image\/(jpeg|jpg|png|webp|gif)$/i.test(mime)) return json({ error: "Unsupported image type" }, 400, origin, env);
        if (String(image.data).length > 7_500_000) return json({ error: "Image is too large" }, 413, origin, env);
        const prompt = `این تصویر یک غذا را نشان می‌دهد که احتمالاً غذای ایرانی است. نام غذا را به فارسی تشخیص بده و مقادیر تخمینی درشت‌مغذی‌ها را به‌ازای هر ۱۰۰ گرم برآورد کن. فقط JSON معتبر و بدون markdown برگردان با این ساختار: {"name":"نام فارسی","kcal":عدد,"protein":عدد,"carb":عدد,"fat":عدد,"confidence":"low|medium|high","note":"یک جمله کوتاه فارسی"}`;
        const data = await callOpenAI({
          model: "gpt-5-mini",
          store: false,
          input: [{
            role: "user",
            content: [
              { type: "input_text", text: prompt },
              { type: "input_image", image_url: `data:${mime};base64,${image.data}`, detail: "auto" },
            ],
          }],
        }, env);
        const text = outputText(data).replace(/^```json\s*|\s*```$/g, "").trim();
        let result;
        try { result = JSON.parse(text); } catch { return json({ error: "AI returned invalid food JSON" }, 502, origin, env); }
        return json({ result }, 200, origin, env);
      }

      return json({ error: "Unknown action" }, 400, origin, env);
    } catch (error) {
      console.error(error);
      return json({ error: error.message || "AI request failed" }, 502, origin, env);
    }
  },
};
